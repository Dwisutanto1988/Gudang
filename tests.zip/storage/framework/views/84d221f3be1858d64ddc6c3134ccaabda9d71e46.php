<?php $__env->startSection('title', __('Products')); ?>
<?php $__env->startSection('custom-css'); ?>
    <link rel="stylesheet" href="/plugins/toastr/toastr.min.css">
    <link rel="stylesheet" href="/plugins/select2/css/select2.min.css">
    <link rel="stylesheet" href="/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
        <div class="row mb-2">
        </div>
        </div>
    </div>
    <section class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add-product" onclick="addProduct()"><i class="fas fa-plus"></i> Add New Product</button>
                <div class="card-tools">
                    <form>
                        <div class="input-group input-group">
                            <input type="text" class="form-control" name="q" placeholder="Search">
                            <input type="hidden" name="category" value="<?php echo e(Request::get('category')); ?>">
                            <input type="hidden" name="sort" value="<?php echo e(Request::get('sort')); ?>">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="form-group row col-sm-2">
                    <label for="sort" class="col-sm-4 col-form-label">Sort</label>
                    <div class="col-sm-8">
                        <form id="sorting" action="" method="get">
                            <input type="hidden" name="q" value="<?php echo e(Request::get('q')); ?>">
                            <input type="hidden" name="category" value="<?php echo e(Request::get('category')); ?>">
                            <select class="form-control select2" style="width: 100%;" id="sort" name="sort">
                                <option value="" <?php echo e(Request::get('sort') == null? 'selected':''); ?>>None</option>
                                <option value="asc" <?php echo e(Request::get('sort') == 'asc'? 'selected':''); ?>>Ascending</option>
                                <option value="desc" <?php echo e(Request::get('sort') == 'desc'? 'selected':''); ?>>Descending</option>
                            </select>
                        </form>
                    </div>
                </div>
                <div class="table-responsive">
                    <table id="table" class="table table-sm table-bordered table-hover table-striped">
                        <thead>
                            <tr class="text-center">
                                <th>No.</th>
                                <th><?php echo e(__('Product Code')); ?></th>
                                <th><?php echo e(__('Product Name')); ?></th>
                                <th><?php echo e(__('Category')); ?></th>
                                <th><?php echo e(__('Amount')); ?></th>
                                <th><?php echo e(__('Purchase Price (Rp)')); ?></th>
                                <th><?php echo e(__('Sale Price (Rp)')); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if(count($products) > 0): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $data = [
                                            "no"        => $products->firstItem() + $key,
                                            "pid"       => $d->product_id,
                                            "pcode"     => $d->product_code,
                                            "pname"     => $d->product_name,
                                            "cname"     => $d->category_name,
                                            "cval"      => $d->category_id,
                                            "pamount"   => $d->product_amount,
                                            "pprice"    => $d->purchase_price,
                                            "sprice"    => $d->sale_price
                                        ];
                            ?>
                            <tr>
                                <td class="text-center"><?php echo e($data['no']); ?></td>
                                <td class="text-center"><?php echo e($data['pcode']); ?></td>
                                <td><?php echo e($data['pname']); ?></td>
                                <td><?php echo e($data['cname']); ?></td>
                                <td class="text-center"><?php echo e($data['pamount']); ?></td>
                                <td class="text-center"><?php echo e(number_format($data['pprice'], 2, ",", ".")); ?></td>
                                <td class="text-center"><?php echo e(number_format($data['sprice'], 2, ",", ".")); ?></td>
                                <td class="text-center"><button title="Edit Produk" type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#add-product" onclick="editProduct(<?php echo e(json_encode($data)); ?>)"><i class="fas fa-edit"></i></button> <button title="Lihat Barcode" type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#lihat-barcode" onclick="barcode(<?php echo e($d->product_code); ?>)"><i class="fas fa-barcode"></i></button> <?php if(Auth::user()->role == 0): ?><button title="Hapus Produk" type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#delete-product" onclick="deleteProduct(<?php echo e(json_encode($data)); ?>)"><i class="fas fa-trash"></i></button><?php endif; ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr class="text-center">
                                <td colspan="8"><?php echo e(__('No data.')); ?></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div>
        <?php echo e($products->appends(request()->except('page'))->links("pagination::bootstrap-4")); ?>

        </div>
    </div>
    <div class="modal fade" id="add-product">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 id="modal-title" class="modal-title"><?php echo e(__('Add New Product')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form role="form" id="save" action="<?php echo e(route('products.save')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="save_id" name="id">
                        <div class="form-group row">
                            <label for="product_code" class="col-sm-4 col-form-label"><?php echo e(__('Product Code')); ?></label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="product_code" name="product_code">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="product_name" class="col-sm-4 col-form-label"><?php echo e(__('Product Name')); ?></label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="product_name" name="product_name">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="purchase_price" class="col-sm-4 col-form-label"><?php echo e(__('Purchase Price')); ?> (Rp)</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="purchase_price" name="purchase_price">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="sale_price" class="col-sm-4 col-form-label"><?php echo e(__('Sale Price')); ?> (Rp)</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="sale_price" name="sale_price">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="category" class="col-sm-4 col-form-label">Category</label>
                            <div class="col-sm-8">
                                <select class="form-control select2" style="width: 100%;" id="category" name="category">
                                </select>
                            </div>
                        </div>
                        <div id="barcode_preview_container" class="form-group row">
                            <label class="col-sm-4 col-form-label">Barcode</label>
                            <div class="col-sm-8">
                                <img id="barcode_preview"/>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                    <button id="button-save" type="button" class="btn btn-primary" onclick="document.getElementById('save').submit();"><?php echo e(__('Tambahkan')); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="lihat-barcode">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 id="modal-title" class="modal-title"><?php echo e(__('Barcode')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="text-center">
                        <input type="hidden" id="pcode_print">
                        <img id="barcode"/>
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('Tutup')); ?></button>
                    <button type="button" class="btn btn-primary" onclick="printBarcode()"><?php echo e(__('Print Barcode')); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="delete-product">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 id="modal-title" class="modal-title"><?php echo e(__('Delete Product')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form role="form" id="delete" action="<?php echo e(route('products.delete')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="hidden" id="delete_id" name="id">
                    </form>
                    <div>
                        <p>Anda yakin ingin menghapus product code <span id="pcode" class="font-weight-bold"></span>?</p>
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('Batal')); ?></button>
                    <button id="button-save" type="button" class="btn btn-danger" onclick="document.getElementById('delete').submit();"><?php echo e(__('Ya, hapus')); ?></button>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    <script src="/plugins/toastr/toastr.min.js"></script>
    <script src="/plugins/select2/js/select2.full.min.js"></script>
    <script>
        $(function () {
            var user_id;
                $('.select2').select2({
                theme: 'bootstrap4'
            });

            $('#product_code').on('change', function() {
                var code = $('#product_code').val();
                if(code != null && code != ""){
                    $("#barcode_preview").attr("src", "/products/barcode/"+code);
                    $('#barcode_preview_container').show();
                }
            });
        });

        $('#sort').on('change', function() {
            $("#sorting").submit();
        });

        function getCategory(val){
            $.ajax({
                url: '/products/categories',
                type: "GET",
                data: {"format": "json"},
                dataType: "json",
                success:function(data) {                    
                    $('#category').empty();
                    $('#category').append('<option value="">.:: Select Category ::.</option>');
                    $.each(data, function(key, value) {
                        if(value.category_id == val){
                            $('#category').append('<option value="'+ value.category_id +'" selected>'+ value.category_name +'</option>');
                        } else {
                            
                            $('#category').append('<option value="'+ value.category_id +'">'+ value.category_name +'</option>');
                        }
                    });
                }
            });
        }

        function resetForm(){
            $('#save').trigger("reset");
            $('#barcode_preview_container').hide();
        }

        function addProduct(){
            $('#modal-title').text("Add New Product");
            $('#button-save').text("Tambahkan");
            resetForm();
            getCategory();
        }

        function editProduct(data){
            $('#modal-title').text("Edit Product");
            $('#button-save').text("Simpan");
            resetForm();
            $('#save_id').val(data.pid);
            $('#product_code').val(data.pcode);
            $('#product_name').val(data.pname);
            $('#purchase_price').val(data.pprice);
            $('#sale_price').val(data.sprice);
            getCategory(data.cval);
            $('#product_code').change();
        }

        function barcode(code){
            $("#pcode_print").val(code);
            $("#barcode").attr("src", "/products/barcode/"+code);
        }

        function printBarcode(){
            var code    = $("#pcode_print").val();
            var url     = "/products/barcode/"+code+"?print=true";
            window.open(url,'window_print','menubar=0,resizable=0');
        }

        function deleteProduct(data){
            $('#delete_id').val(data.pid);
            $('#pcode').text(data.pcode);
        }
    </script>
    <?php if(Session::has('success')): ?>
        <script>toastr.success('<?php echo Session::get("success"); ?>');</script>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <script>toastr.error('<?php echo Session::get("error"); ?>');</script>
    <?php endif; ?>
    <?php if(!empty($errors->all())): ?>
        <script>toastr.error('<?php echo implode("", $errors->all("<li>:message</li>")); ?>');</script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Gudang\resources\views/products.blade.php ENDPATH**/ ?>