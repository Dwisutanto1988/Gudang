<?php $__env->startSection('title', __('Stock History')); ?>
<?php $__env->startSection('custom-css'); ?>
    <link rel="stylesheet" href="/plugins/toastr/toastr.min.css">
    <link rel="stylesheet" href="/plugins/select2/css/select2.min.css">
    <link rel="stylesheet" href="/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
        <div class="row mb-2">
        </div>
        </div>
    </div>
    <section class="content">
    <div class="container-fluid">
        <div class="card">

            <div class="card-body">

                <div class="table-responsive">

                    <form >
                        <button class="btn btn-warning" onClick="window.location.reload();">Cari</button>  <input class="btn btn-danger" type="reset" value="Reset">
                    <table cellspacing="5" cellpadding="5" border="0">
                        <tbody><tr>
                            <td>Minimum date:</td>
                            <td><input type="text" id="min" name="min"></td>
                        </tr>
                        <tr>
                            <td>Maximum date:</td>
                            <td><input type="text" id="max" name="max"></td>
                        </tr>
                    </tbody></table></form>
                     <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr class="text-center">
                                <th>Type</th>
                                <th><?php echo e(__('Product Code')); ?></th>
                                <th><?php echo e(__('Product Name')); ?></th>
                                <th><?php echo e(__('Amount')); ?></th>
                                <th><?php echo e(__('Shelf Name')); ?></th>
                                <th><?php echo e(__('User')); ?></th>
                                <th><?php echo e(__('Date')); ?></th>
                                <th><?php echo e(__('Ending Amount')); ?></th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    if($d->type == 1){
                                        $type = "IN";
                                    } else {
                                        $type = "OUT";
                                    }
                                ?>
                                <tr>
                                    <td class="text-center <?php echo e(($type == 'IN')? 'text-success':'text-danger'); ?> font-weight-bold"><?php echo e($type); ?></td>
                                    <td class="text-center"><?php echo e($d->product_code); ?></td>
                                    <td><?php echo e($d->product_name); ?></td>
                                    <td class="text-center"><?php echo e($d->product_amount); ?></td>
                                    <td class="text-center"><?php echo e($d->shelf_name); ?></td>
                                    <td class="text-center"><?php echo e($d->name); ?></td>
                                    <td class="text-center"><?php echo e(date('Y-m-d', strtotime($d->datetime))); ?></td>
                                    <td class="text-center"><?php echo e($d->ending_amount); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    <script src="/plugins/toastr/toastr.min.js"></script>
    <script src="/plugins/select2/js/select2.full.min.js"></script>
    <script>
        $(function () {
            $('.select2').select2({
            theme: 'bootstrap4'
            });
        });

        $('#sort').on('change', function() {
            $("#sorting").submit();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Gudang\resources\views/stock_history.blade.php ENDPATH**/ ?>