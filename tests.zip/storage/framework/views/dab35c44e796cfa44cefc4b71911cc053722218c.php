<?php $__env->startSection('title', __('Shelf')); ?>
<?php $__env->startSection('custom-css'); ?>
    <link rel="stylesheet" href="/plugins/toastr/toastr.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
        <div class="row mb-2">
        </div>
        </div>
    </div>
    <section class="content">
    <div class="container-fluid">
        <div class="card">
        <div class="card-header">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add-shelf" onclick="addShelf()"><i class="fas fa-plus"></i> Add New Shelf</button>
        </div>
        <div class="card-body">
            <table id="table" class="table table-sm table-bordered table-hover table-striped">
            <thead>
                <tr class="text-center">
                    <th>No.</th>
                    <th><?php echo e(__('Shelf Name')); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php if(count($shelf) > 0): ?>
                <?php $__currentLoopData = $shelf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $data = ["shelf_id" => $d->shelf_id, "shelf_name" => $d->shelf_name];
                ?>
                <tr>
                    <td class="text-center"><?php echo e($shelf->firstItem() + $key); ?></td>
                    <td><?php echo e($data['shelf_name']); ?></td>
                    <td class="text-center"><button title="Edit Shelf" type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#add-shelf" onclick="editShelf(<?php echo e(json_encode($data)); ?>)"><i class="fas fa-edit"></i></button> <button title="Hapus Shelf" type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#delete-shelf" onclick="deleteShelf(<?php echo e(json_encode($data)); ?>)"><i class="fas fa-trash"></i></button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr class="text-center">
                    <td colspan="3"><?php echo e(__('No data.')); ?></td>
                </tr>
            <?php endif; ?>
            </tbody>
            </table>
        </div>
        </div>
        <div>
        <?php echo e($shelf->links("pagination::bootstrap-4")); ?>

        </div>
    </div>
    <div class="modal fade" id="add-shelf">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 id="modal-title" class="modal-title"><?php echo e(__('Add New Shelf')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form role="form" id="update" action="<?php echo e(route('products.shelf.save')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="shelf_id" name="shelf_id">
                        <div class="form-group row">
                            <label for="shelf_name" class="col-sm-4 col-form-label"><?php echo e(__('Name')); ?></label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="shelf_name" name="shelf_name">
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                    <button id="button-save" type="button" class="btn btn-primary" onclick="$('#update').submit();"><?php echo e(__('Add')); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="delete-shelf">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 id="modal-title" class="modal-title"><?php echo e(__('Hapus Shelf')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form role="form" id="delete" action="<?php echo e(route('products.shelf.delete')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="hidden" id="delete_id" name="delete_id">
                    </form>
                    <div>
                        <p class="text-danger">Perhatian! Stok serta history yang berada di shelf ini juga akan ikut terhapus!</p>
                        <p>Anda yakin ingin tetap menghapus shelf <span id="delete_name" class="font-weight-bold"></span>?</p>
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                    <button id="button-delete" type="button" class="btn btn-danger" onclick="$('#delete').submit();"><?php echo e(__('Ya, hapus')); ?></button>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    <script>
        function resetForm(){
            $('#update').trigger("reset");
            $('#shelf_id').val('');
        }

        function addShelf(){
            resetForm();
            $('#modal-title').text("Add New Shelf");
            $('#button-save').text("Add");
        }

        function editShelf(data){
            resetForm();
            $('#modal-title').text("Edit Shelf");
            $('#button-save').text("Simpan");
            $('#shelf_id').val(data.shelf_id);
            $('#shelf_name').val(data.shelf_name);
        }

        function deleteShelf(data){
            $('#delete_id').val(data.shelf_id);
            $('#delete_name').text(data.shelf_name);
        }
    </script>
    <script src="/plugins/toastr/toastr.min.js"></script>
    <?php if(Session::has('success')): ?>
        <script>toastr.success('<?php echo Session::get("success"); ?>');</script>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <script>toastr.error('<?php echo Session::get("error"); ?>');</script>
    <?php endif; ?>
    <?php if(!empty($errors->all())): ?>
        <script>toastr.error('<?php echo implode("", $errors->all("<li>:message</li>")); ?>');</script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Gudang\resources\views/shelf.blade.php ENDPATH**/ ?>