<?php $__env->startSection('title', __('Users')); ?>
<?php $__env->startSection('custom-css'); ?>
    <link rel="stylesheet" href="/plugins/toastr/toastr.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
        <div class="row mb-2">
        </div>
        </div>
    </div>
    <section class="content">
    <div class="container-fluid">
        <div class="card">
        <div class="card-header">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add-user" onclick="addUser()"><i class="fas fa-plus"></i> Add New User</button>
        </div>
        <div class="card-body">
            <table id="table" class="table table-sm table-bordered table-hover table-striped">
            <thead>
                <tr class="text-center">
                    <th>No.</th>
                    <th><?php echo e(__('Fullname')); ?></th>
                    <th><?php echo e(__('Username')); ?></th>
                    <th><?php echo e(__('Role')); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php if(count($users) > 0): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $data = ["user_id" => $d->id, "fullname" => $d->name, "username" => $d->username, "role" => $d->role];
                    if($d->role == 0){
                        $role = "Admin";
                    } else {
                        $role = "User";
                    }
                ?>
                <tr>
                    <td class="text-center"><?php echo e($users->firstItem() + $key); ?></td>
                    <td><?php echo e($data['fullname']); ?></td>
                    <td><?php echo e($data['username']); ?></td>
                    <td><?php echo e($role); ?></td>
                    <td class="text-center"><button title="Edit User" type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#add-user" onclick="editUser(<?php echo e(json_encode($data)); ?>)"><i class="fas fa-edit"></i></button> <button title="Hapus User" type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#delete-user" onclick="deleteUser(<?php echo e(json_encode($data)); ?>)"><i class="fas fa-trash"></i></button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr class="text-center">
                    <td colspan="4"><?php echo e(__('No user.')); ?></td>
                </tr>
            <?php endif; ?>
            </tbody>
            </table>
        </div>
        </div>
        <div>
        <?php echo e($users->links("pagination::bootstrap-4")); ?>

        </div>
    </div>
    <div class="modal fade" id="add-user">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 id="modal-title" class="modal-title"><?php echo e(__('Add New User')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form role="form" id="update" action="<?php echo e(route('users.save')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="user_id" name="user_id">
                        <div class="form-group row">
                            <label for="username" class="col-sm-4 col-form-label"><?php echo e(__('Username')); ?></label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="username" name="username">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fullname" class="col-sm-4 col-form-label"><?php echo e(__('Name')); ?></label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="fullname" name="fullname">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="password" class="col-sm-4 col-form-label"><?php echo e(__('Password')); ?></label>
                            <div class="col-sm-8">
                                <input type="password" class="form-control" id="password" name="password">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="role" class="col-sm-4 col-form-label">Role</label>
                            <div class="col-sm-8">
                                <select class="form-control select2" style="width: 100%;" id="role" name="role">
                                    <option value="">.:: Select Role ::.</option>
                                    <option value="0">Admin</option>
                                    <option value="1">User</option>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                    <button id="button-save" type="button" class="btn btn-primary" onclick="$('#update').submit();"><?php echo e(__('Add')); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="delete-user">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 id="modal-title" class="modal-title"><?php echo e(__('Hapus User')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form role="form" id="delete" action="<?php echo e(route('users.delete')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="hidden" id="delete_id" name="delete_id">
                        <input type="hidden" id="delete_role" name="delete_role">
                    </form>
                    <div>
                        <p>Anda yakin ingin menghapus user <span id="delete_name" class="font-weight-bold"></span>?</p>
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                    <button id="button-delete" type="button" class="btn btn-danger" onclick="$('#delete').submit();"><?php echo e(__('Ya, hapus')); ?></button>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    <script>
        function resetForm(){
            $('#update').trigger("reset");
            $('#user_id').val('');
        }

        function addUser(){
            resetForm();
            $('#modal-title').text("Add New User");
            $('#button-save').text("Add");
        }

        function editUser(data){
            resetForm();
            $('#modal-title').text("Edit User");
            $('#button-save').text("Simpan");
            $('#user_id').val(data.user_id);
            $('#fullname').val(data.fullname);
            $('#username').val(data.username);
            $('#role').val(data.role);
        }

        function deleteUser(data){
            $('#delete_id').val(data.user_id);
            $('#delete_name').text(data.username);
            $('#delete_role').val(data.role);
        }
    </script>
    <script src="/plugins/toastr/toastr.min.js"></script>
    <?php if(Session::has('success')): ?>
        <script>toastr.success('<?php echo Session::get("success"); ?>');</script>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <script>toastr.error('<?php echo Session::get("error"); ?>');</script>
    <?php endif; ?>
    <?php if(!empty($errors->all())): ?>
        <script>toastr.error('<?php echo implode("", $errors->all("<li>:message</li>")); ?>');</script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Gudang\resources\views/users.blade.php ENDPATH**/ ?>