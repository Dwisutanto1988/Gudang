<?php $__env->startSection('title', __('Work In Progress (WIP)')); ?>
<?php $__env->startSection('custom-css'); ?>
    <link rel="stylesheet" href="/plugins/toastr/toastr.min.css">
    <link rel="stylesheet" href="/plugins/select2/css/select2.min.css">
    <link rel="stylesheet" href="/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
        <div class="row mb-2">
        </div>
        </div>
    </div>
    <section class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add-product" onclick="addProduct()"><i class="fas fa-plus"></i> Add New WIP</button>
                <div class="card-tools">
                    <form>
                        <div class="input-group input-group">
                            <input type="text" class="form-control" name="q" placeholder="Search">
                            <input type="hidden" name="category" value="<?php echo e(Request::get('category')); ?>">
                            <input type="hidden" name="sort" value="<?php echo e(Request::get('sort')); ?>">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="form-group row col-sm-2">
                    <label for="sort" class="col-sm-4 col-form-label">Sort</label>
                    <div class="col-sm-8">
                        <form id="sorting" action="" method="get">
                            <input type="hidden" name="q" value="<?php echo e(Request::get('q')); ?>">
                            <input type="hidden" name="category" value="<?php echo e(Request::get('category')); ?>">
                            <select class="form-control select2" style="width: 100%;" id="sort" name="sort">
                                <option value="" <?php echo e(Request::get('sort') == null? 'selected':''); ?>>None</option>
                                <option value="asc" <?php echo e(Request::get('sort') == 'asc'? 'selected':''); ?>>Ascending</option>
                                <option value="desc" <?php echo e(Request::get('sort') == 'desc'? 'selected':''); ?>>Descending</option>
                            </select>
                        </form>
                    </div>
                </div>
                <div class="table-responsive">
                    <table id="table" class="table table-sm table-bordered table-hover table-striped">
                        <thead>
                            <tr class="text-center">
                                <th>No.</th>
                                <th><?php echo e(__('Product Code')); ?></th>
                                <th><?php echo e(__('Product Name')); ?></th>
                                <th><?php echo e(__('Amount')); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if(count($products) > 0): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $data = [
                                            "no"        => $products->firstItem() + $key,
                                            "pid"       => $d->product_wip_id,
                                            "pcode"     => $d->product_code,
                                            "pname"   => $d->product_name,
                                            "pamount"   => $d->product_amount,
                                        ];
                            ?>
                            <tr>
                                <td class="text-center"><?php echo e($data['no']); ?></td>
                                <td class="text-center"><?php echo e($data['pcode']); ?></td>
                                <td><?php echo e($data['pname']); ?></td>
                                <td><?php echo e($data['pamount']); ?></td>
                                <td class="text-center"><button title="Selesai" type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#wip-complete" onclick="wipComplete(<?php echo e(json_encode($data)); ?>)"><i class="fas fa-check"></i></button> <button title="Edit" type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#add-product" onclick="editProduct(<?php echo e(json_encode($data)); ?>)"><i class="fas fa-edit"></i></button> <button title="Hapus" type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#delete-product" onclick="deleteProduct(<?php echo e(json_encode($data)); ?>)"><i class="fas fa-trash"></i></button></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr class="text-center">
                                <td colspan="8"><?php echo e(__('No data.')); ?></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div>
        <?php echo e($products->appends(request()->except('page'))->links("pagination::bootstrap-4")); ?>

        </div>
    </div>
    <div class="modal fade" id="add-product">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 id="modal-title" class="modal-title"><?php echo e(__('Add New WIP')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form role="form" id="save" action="<?php echo e(route('products.wip.save')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="save_id" name="id">
                        <div class="form-group row">
                            <label for="product_code" class="col-sm-4 col-form-label"><?php echo e(__('Product Code')); ?></label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="product_code" name="product_code">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="product_amount" class="col-sm-4 col-form-label"><?php echo e(__('Amount')); ?></label>
                            <div class="col-sm-8">
                                <input type="number" class="form-control" id="product_amount" name="product_amount" min="1">
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                    <button id="button-save" type="button" class="btn btn-primary" onclick="$('#save').submit();"><?php echo e(__('Tambahkan')); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="delete-product">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 id="modal-title" class="modal-title"><?php echo e(__('Delete Product')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form role="form" id="delete" action="<?php echo e(route('products.wip.delete')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="hidden" id="delete_id" name="id">
                    </form>
                    <div>
                        <p>Anda yakin ingin menghapus product code <span id="pcode" class="font-weight-bold"></span>?</p>
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('Batal')); ?></button>
                    <button id="button-save" type="button" class="btn btn-danger" onclick="$('#delete').submit();"><?php echo e(__('Ya, hapus')); ?></button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="wip-complete">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 id="modal-title" class="modal-title"><?php echo e(__('Selesai')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form role="form" id="complete" action="<?php echo e(route('products.wip.complete')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="wip_id" name="wip_id">
                    </form>
                    <div>
                        <p>Anda yakin WIP product code <span id="wip_pcode" class="font-weight-bold"></span> sudah selesai?</p>
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('Batal')); ?></button>
                    <button id="button-save" type="button" class="btn btn-success" onclick="$('#complete').submit();"><?php echo e(__('Ya')); ?></button>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    <script src="/plugins/toastr/toastr.min.js"></script>
    <script src="/plugins/select2/js/select2.full.min.js"></script>
    <script>
        $(function () {
            var user_id;
            $('.select2').select2({
            theme: 'bootstrap4'
            });
        });

        $('#sort').on('change', function() {
            $("#sorting").submit();
        });

        function resetForm(){
            $('#save').trigger("reset");
        }

        function addProduct(){
            $('#modal-title').text("Add New WIP");
            $('#button-save').text("Tambahkan");
            resetForm();
        }

        function editProduct(data){
            $('#modal-title').text("Edit");
            $('#button-save').text("Simpan");
            resetForm();
            $('#save_id').val(data.pid);
            $('#product_code').val(data.pcode);
            $('#product_name').val(data.pname);
            $('#product_amount').val(data.pamount);
        }

        function wipComplete(data){
            $('#wip_id').val(data.pid);
            $('#wip_pcode').text(data.pcode);
        }

        function deleteProduct(data){
            $('#delete_id').val(data.pid);
            $('#pcode').text(data.pcode);
        }
    </script>
    <?php if(Session::has('success')): ?>
        <script>toastr.success('<?php echo Session::get("success"); ?>');</script>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <script>toastr.error('<?php echo Session::get("error"); ?>');</script>
    <?php endif; ?>
    <?php if(!empty($errors->all())): ?>
        <script>toastr.error('<?php echo implode("", $errors->all("<li>:message</li>")); ?>');</script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Gudang\resources\views/products_wip.blade.php ENDPATH**/ ?>